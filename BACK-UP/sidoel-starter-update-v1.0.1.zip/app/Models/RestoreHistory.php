<?php

   namespace App\Models;

   use Illuminate\Database\Eloquent\Model;

   class RestoreHistory extends Model
   {
      protected $guarded = ['id'];
      protected $dates   = ['restored_at'];

      // Relasi ke User (Admin yang merestore)
      public function actor() {
         return $this->belongsTo(User::class, 'user_id');
      }
   }
