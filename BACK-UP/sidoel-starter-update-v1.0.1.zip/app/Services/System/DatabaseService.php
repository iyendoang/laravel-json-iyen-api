<?php

    namespace App\Services\System;

    use App\Models\Backup;
    use Illuminate\Support\Facades\Log;
    use Symfony\Component\Process\Process;
    use Symfony\Component\Process\Exception\ProcessFailedException;

    class DatabaseService
    {
        protected $dbName;
        protected $dbUser;
        protected $dbPass;
        protected $dbHost;
        protected $encryptionKey;
        protected $maxBackups = 5;

        // Path Binary
        protected $pathMysql;
        protected $pathDump;
        protected $pathOpenssl;

        public function __construct() {
            // 1. Load Database Config
            $this->dbName = config('database.connections.mysql.database');
            $this->dbUser = config('database.connections.mysql.username');
            $this->dbPass = config('database.connections.mysql.password');
            $this->dbHost = config('database.connections.mysql.host');

            // 2. Load Secret Key
            $this->encryptionKey = config('services.sidoel.secret_key', 'S1D03LBI54D0N6');

            // 3. Load Binary Paths (Dari Config, bukan Env langsung)
            $this->pathMysql   = config('services.binaries.mysql', 'mysql');
            $this->pathDump    = config('services.binaries.mysqldump', 'mysqldump');
            $this->pathOpenssl = config('services.binaries.openssl', 'openssl');
        }

        /**
         * Membuat Backup Terenkripsi (.sidosts)
         * Menggunakan AES-256 dan menyembunyikan Password/Key dari Process List
         */
        public function createBackup($prefix = 'backup') {
            $fileName    = $prefix . '_' . date('Y-m-d_H-i-s') . '.sidosts';
            $storagePath = storage_path('app/backups');

            if (!file_exists($storagePath)) {
                mkdir($storagePath, 0755, true);
            }

            $filePath = $storagePath . DIRECTORY_SEPARATOR . $fileName;

            // --- COMMAND CONSTRUCTION ---
            // Perhatikan: Kita TIDAK menyertakan --password=... atau -k ... di sini.
            // Kita menggunakan variable environment agar tidak muncul di 'ps aux' (process list).

            $command = sprintf(
                '%s --user=%s --host=%s %s | %s enc -aes-256-cbc -pbkdf2 -salt -pass env:BACKUP_KEY > %s',
                escapeshellcmd($this->pathDump),
                escapeshellarg($this->dbUser),
                escapeshellarg($this->dbHost),
                escapeshellarg($this->dbName),
                escapeshellcmd($this->pathOpenssl),
                escapeshellarg($filePath)
            );

            // --- ENVIRONMENT VARIABLES ---
            // Injeksi password dan key ke dalam proses secara rahasia
            $envVars = [
                'MYSQL_PWD'  => $this->dbPass,       // Mysqldump otomatis baca variable ini
                'BACKUP_KEY' => $this->encryptionKey // Openssl membaca ini via "-pass env:BACKUP_KEY"
            ];

            try {
                // Log command aman karena tidak ada password di string $command
                Log::info("Starting Backup Process...", ['file' => $fileName]);

                $this->runProcess($command, $envVars);

                if (file_exists($filePath) && filesize($filePath) > 0) {
                    Backup::create([
                        'filename' => $fileName,
                        'path'     => $filePath,
                        'size'     => filesize($filePath),
                    ]);

                    Log::info("Backup sukses dan terenkripsi.");
                    $this->pruneOldBackups();

                    return $filePath;
                } else {
                    throw new \Exception("File backup terbentuk tapi kosong (0 bytes).");
                }
            } catch (\Exception $e) {
                Log::error("Backup Gagal: " . $e->getMessage());
                // Hapus file corrupt jika ada
                if (file_exists($filePath)) @unlink($filePath);
                throw $e;
            }
        }

        /**
         * Restore Database dari file .sidosts
         */
        public function restoreDatabase($fullPath) {
            if (!file_exists($fullPath)) {
                throw new \Exception("File backup tidak ditemukan: " . $fullPath);
            }

            Log::warning("Memulai Restore Database...", ['file' => basename($fullPath)]);

            // --- COMMAND CONSTRUCTION ---
            // Urutan: OpenSSL Decrypt -> MySQL Import
            // Password DB dan Key Enkripsi disembunyikan via ENV

            $command = sprintf(
                '%s enc -d -aes-256-cbc -pbkdf2 -salt -pass env:BACKUP_KEY -in %s | %s --user=%s --host=%s %s',
                escapeshellcmd($this->pathOpenssl),
                escapeshellarg($fullPath),
                escapeshellcmd($this->pathMysql),
                escapeshellarg($this->dbUser),
                escapeshellarg($this->dbHost),
                escapeshellarg($this->dbName)
            );

            // --- ENVIRONMENT VARIABLES ---
            $envVars = [
                'MYSQL_PWD'  => $this->dbPass,       // Mysql client otomatis baca variable ini
                'BACKUP_KEY' => $this->encryptionKey // Openssl membaca ini
            ];

            try {
                $this->runProcess($command, $envVars);
                Log::info("Restore Database Berhasil Diselesaikan.");

                return true;
            } catch (\Exception $e) {
                Log::error("Restore Gagal: " . $e->getMessage());
                throw $e;
            }
        }

        /**
         * Hapus Backup Lama (> 5)
         */
        protected function pruneOldBackups() {
            $count = Backup::count();
            if ($count > $this->maxBackups) {
                $deleteCount = $count - $this->maxBackups;
                $oldBackups  = Backup::orderBy('created_at', 'asc')->take($deleteCount)->get();

                foreach ($oldBackups as $backup) {
                    if (file_exists($backup->path)) {
                        @unlink($backup->path); // Pakai @ untuk suppress error jika file sudah hilang manual
                    }
                    $backup->delete();
                }
                Log::info("Pruning: Menghapus $deleteCount backup lama.");
            }
        }

        /**
         * Menjalankan perintah shell dengan environment variables terisolasi
         */
        private function runProcess($command, $env = []) {
            // Create Process
            $process = Process::fromShellCommandline($command);

            // Set Timeout (Default 10 Menit)
            $process->setTimeout(600);

            // Set Environment Variables (Password & Key disuntikkan di sini)
            if (!empty($env)) {
                $process->setEnv($env);
            }

            // Jalankan
            $process->run();

            // Cek Error
            if (!$process->isSuccessful()) {
                // Kita throw error, tapi kita filter outputnya agar password tidak bocor di log error
                // (Meski sudah pakai ENV, best practice tetap hati-hati dengan output error)
                throw new ProcessFailedException($process);
            }
        }
    }
